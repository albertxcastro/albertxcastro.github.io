# Simple messages queue for communication between agents
# Singleton used to save a shared state
from util.communication.message import Message


class MessageQueue(object):
    _shared_borg_state = {}
    queue = []

    def __new__(cls, *args, **kwargs):
        obj = super(MessageQueue, cls).__new__(cls, *args, **kwargs)
        obj.__dict__ = cls._shared_borg_state
        return obj

    def append(self, message: Message):
        self.queue.append(message)

    # get any message for agent
    def get(self, agent) -> Message:
        for message in self.queue:
            if message.to_agent == agent:
                index = self.queue.index(message)
                return self.queue.pop(index)

        return None

    def print_all(self):
        print("MessageQueue messages")
        for row in self.queue:
            print("\tFrom: " + str(row.from_agent) + ", To: " + str(row.to_agent) + ", Message: " + str(row.message))
