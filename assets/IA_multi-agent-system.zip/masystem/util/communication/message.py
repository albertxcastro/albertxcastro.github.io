class Message:
    def __init__(self, from_agent, to_agent, message):
        self.from_agent = from_agent
        self.to_agent = to_agent
        self.message = message
