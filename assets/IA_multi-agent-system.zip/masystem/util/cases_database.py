# agent's knowledge databases
class CasesDatabase:

    def __init__(self, data):
        self.data = data
        self.found_data = set()
        self.discarded_data = set()

    def add(self, record):
        self.found_data.add(record)

    def discard(self, record):
        self.discarded_data.add(record)

    def print_data(self):
        print("\nDatabase: show all stored DNA data.")
        for row in self.data:
            print("\tDNA sample: " + str(row))
        print("\n")
        