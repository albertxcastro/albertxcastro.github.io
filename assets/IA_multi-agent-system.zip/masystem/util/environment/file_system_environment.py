# FS Environment simple agent
# generates test data that represents DNA requests as inputs to multi-agent system
# by legend requests are made by creating text files in some directory
from util.environment.file_system_emulator import FileSystemEmulator


class FsEnvironment:
    def __init__(self, file_system_emulator: FileSystemEmulator):
        self.file_system_emulator = file_system_emulator

    # test function: environment provides random document - a request for DNA analysis for new or present case
    # (Message to discoveryAgent) for real prototype, it should be FS reading code which makes searches on accessible
    # filesystems
    def generate_random_samples(self):
        files = self.file_system_emulator.read_files()

        if len(files) == 0:
            random_sample = self.file_system_emulator.add_random_sample()
            print(f"Fyle system: New file {random_sample} with DNA request has been sent")
