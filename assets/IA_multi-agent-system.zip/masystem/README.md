# Multi-Agent System in Digital Forensics

## Requirements
```commandline
python >= 3.10
unittest
```
## How to run
Open a terminal and navigate to the root folder of the project `masystem`. After that
type the following command and type enter:
```
python playground.py 
```
After that, the program will start and agents will start working. Two new directories will be created
in the same folder where `playground.py` lives: `samples` and `deleted_samples`. This is normal,
and those files can be removed manually after the execution of `playground.py` is interrupted. Those
directories are used by the file system emulator to place fake DNA sample files. After the execution
of the program, all files must be placed inside `deleted_samples`. This is because the file system emulator
creates DNA sample files and places them inside `samples`, but the `DiscoveryAgent` moves them to
`deleted_samples` after it analyses them.

To interrupt the program, type `Ctrl + C` in the terminal where it is running. You must see an output like this:
```
^C
User interruption detected. Exiting...

********** Samples found during analysis **********
dna sample
[2, 2, 3]
[2, 1, 2]


********** Samples discarded during analysis **********
dna sample
[1, 3, 1]
[2, 2, 2]
[2, 2, 1]
```

## How to run unit tests

Open a terminal and navigate to the root folder of the project `masystem`. After that
type the following command and type enter:
```
python -m unittest
```
That command will execute all tests contained in the `tests` directory. After executing the command
above, you must see the following output:
```
Ran 21 tests in 0.005s

OK
```

This means that all tests were executed correctly. Since tests are safeguards of our code, they can 
fail if we change the logic in our code. If we make code updates and break existing logic, we will see
an output like this after executing tests:
```
======================================================================
FAIL: test_get (tests.agents.test_message_queue.TestMessageQueue)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/masystem/tests/agents/test_message_queue.py", line 16, in test_get
    self.assertIsNone(fetched_message)
AssertionError: <util.communication.message.Message object at 0x100890b80> is not None

----------------------------------------------------------------------
Ran 21 tests in 0.004s

FAILED (failures=1)
```
In this case, the test `test_get` from the test class `TestMessageQueue` was expecting a `Message`
instance to be `None`, but it was `not None`. 

## Implementation
### Classes
#### Main classes
The project is divided into three main and several utility classes. 
The main classes are the agents contained in the `agents` directory.

```
agents
├── base_agent.py
├── discovery_agent.py
├── dna_agent.py
```

- `base_agent.py` represents a basic intelligent agent: it can sense its
environment using a `sensor` module, can perform actions using an `actuator` module
and can analyse inputs using its `analysis_module`. All three dependencies are
interfaces, and can be injected using dependency injection though the constructor 
of the class. With this approach we can instantiate any number of different agents, each one 
using their own implementations.

- `discovery_agent.py` is the agent responsible for sensing DNA samples from its environment 
(a directory in the file system) and sending them for further analysis. This agent also emits
notifications when a DNA sample was found in the system.
  - This agent has its own dependencies living in the same file:
    - `sensor`: `DiscoverySensor` class.
    - `actuator`: `DiscoveryActuator` class.
    - `analysis_module`: `discoveryAnalysisModule` class.

- `dna_agent.py` is the agent responsible for checking if DNA samples exists in its internal database.
It also separates DNA samples into two different databases: DNA samples that were found and those 
that were discarded.
  - This agent has its own dependencies living in the same file:
      - `sensor`: `DNARequestSensor` class.
      - `actuator`: `DNARequestActuator` class.
      - `analysis_module`: `DNAAnalysisModule` class.

#### Utility classes
Utility classes support agents' communication tasks, provide logic for environment emulation 
(file system emulation), and logic that emulates agents' data layer storage. These classes 
live inside the `util` directory.

```
util
├── cases_database.py
├── communication
│   ├── kqml_parser.py
│   ├── message.py
│   └── message_queue.py
└── environment
    ├── file_system_emulator.py
    └── file_system_environment.py
```

#### Unit testing classes
Finally, the project is well tested using several unit tests. Tests live under the `tests` directory.
They were implemented usig the [unittest](https://docs.python.org/3/library/unittest.html) framework.
This framework provides a `TestCase` class that represents a unit test, and contains all the necessary
logic to make assertions.

```
tests
├── __init__.py
├── agents
│   ├── __init__.py
│   ├── test_discovery_agent.py
│   ├── test_dna_agent.py
│   └── test_message_queue.py
└── util
    ├── __init__.py
    ├── test_file_system_emulator.py
    └── test_kqml_parser.py
```